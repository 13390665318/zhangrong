<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/6/15 0015
 * Time: 下午 4:59
 * 91000003   体力
 */

namespace Home\Controller;


class EquiplogController extends BaseController
{
    public function index()
    {

        $clostu = D("db")->order("db_id desc")->select();
        $this->assign("clostu", $clostu);

        // 图标 默认 最新服
        if ($db_id != 0) {
            $ru['server'] = $db_id;
        }


        if (isset($_GET["start_time"]) && isset($_GET["end_time"])) {
            $stime = I("get.start_time");
            $stime=date("Y-m-d 00:00:00", strtotime($stime));
            $etime=date("Y-m-d 23:59:59", strtotime($stime));
        } else {
            $stime = date("Y-m-d 00:00:00", time());
            $etime = date("Y-m-d 23:59:59", time());
        }


        $stime1=date("Y-m-d", strtotime($stime));
        $this->assign('Stime',$stime1);
        $this->assign('Etime',$etime);

        if($_GET['game_user_id']){
            $game_user_id=I('get.game_user_id');
            $ru['role_id']=$game_user_id;
            $this->assign('role_id',$game_user_id);
        }

        if($_GET['game_user_name']){
            $game_user_name=I('get.game_user_name');
            $ru['role_name']=$game_user_name;
            $this->assign('role_name',$game_user_name);
        }

        $ru['LogTime']=array(array('gt',$stime),array('lt',$etime));
        $model=D('equiplog');
        $count=$model->where($ru)->count();
        $Page=new \Think\Page($count,20);
        $show=$Page->show();
        $equiplog = $model->limit($Page->firstRow.','.$Page->listRows)->where($ru)->select();
        foreach ($equiplog as $key =>$value){
            $equiplog[$key]['equipInfo']=json_decode($value['equipInfo'],1);
            $equiplog[$key]['consumeInfo']=json_decode($value['consumeInfo'],1);
            $equiplog[$key]['leftInfo']=json_decode($value['leftInfo'],1);
        }

        $this->assign('equiplog', $equiplog);
        $this->assign('page',$show);
        $this->display();


    }


    public function exl()
    {
        header("Content-Type:text/html; charset=utf-8");
        Vendor('PHPExcel.PHPExcel');
        //判断获得时间
        $clostu = D("db")->order("db_id desc")->select();
        $this->assign("clostu", $clostu);

        // 图标 默认 最新服
        if (isset($_GET["db_id"])) {
            $db_id = I("db_id");
        } else {
            $db_id = $clostu[0]["db_id"];
        }
        if ($db_id != 0) {
            $ru['server'] = $db_id;
        }

        $this->assign("db_id", $db_id);
        if (isset($_GET["start_time"]) && isset($_GET["end_time"])) {
            $stime = I("get.start_time");
            $stime=date("Y-m-d 00:00:00", strtotime($stime));
            $etime=date("Y-m-d 23:59:59", strtotime($stime));
        } else {
            $stime = date("Y-m-d 00:00:00", time());
            $etime = date("Y-m-d 23:59:59", time());
        }


        $stime1=date("Y-m-d", strtotime($stime));


        if($_GET['game_user_id']){
            $game_user_id=I('get.game_user_id');
            $ru['role_id']=$game_user_id;
        }

        if($_GET['game_user_name']){
            $game_user_name=I('get.game_user_name');
            $ru['role_name']=$game_user_name;
        }

        $ru['LogTime']=array(array('gt',$stime),array('lt',$etime));
        $model=D('equiplog');
        $equiplog = $model->where($ru)->select();


        $objPHPExcel = new \PHPExcel();

        //设置excel列名

        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', '时间');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B1', '角色ID');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C1', '角色名称');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D1', '装备ID');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E1', '装备类型');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F1', '操作类型');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G1', '操作前属性');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H1', '操作后属性');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I1', '物品消耗信息');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J1', '物品剩余数量');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K1', '游戏币消耗');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L1', '游戏币剩余');

        //把数据循环写入excel中
        $i = 1;
        foreach ($equiplog as $key => $value) {
            $key += 2;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $key, $value["LogTime"]);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $key, $value['role_id']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $key, $value['role_name']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $key, $value['equip_id']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $key, $value['equip_type']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $key, $value['equip_operation']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $key, $value['preequip']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $key, $value['laterequip']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I' . $key, $value['item_use']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J' . $key, $value['item_left']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K' . $key, $value['gold_use']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L' . $key, $value['gold_left']);
        }
        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setAutoSize(true);

        //导出代码
        $name='装备操作日志'.$stime1;
        $objPHPExcel->getActiveSheet()->setTitle('User');
        $objPHPExcel->setActiveSheetIndex(0);
        ob_end_clean();//清除缓冲区,避免乱码
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . $name . '.xls"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        $objWriter->save('php://output');
        exit;
    }

}