<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/8/8 0008
 * Time: 下午 2:16
 */

namespace Home\Controller;


class UseronlineController extends BaseController
{
    public function index(){

    }

}