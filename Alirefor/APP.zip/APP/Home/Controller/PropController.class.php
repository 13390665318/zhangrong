<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/6/15 0015
 * Time: 下午 3:11
 */

namespace Home\Controller;


class PropController extends BaseController
{
    public function index(){

        $clostu = D("db")->order("db_id desc")->select();
        $this->assign("clostu", $clostu);

        // 图标 默认 最新服
        if ($db_id != 0) {
            $ru['server'] = $db_id;
        }
        
        if (isset($_GET["start_time"]) && isset($_GET["end_time"])) {
            $stime = I("get.start_time");
            $stime=date("Y-m-d 00:00:00", strtotime($stime));
            $etime=date("Y-m-d 23:59:59", strtotime($stime));
        } else {
            $stime = date("Y-m-d 00:00:00", time());
            $etime = date("Y-m-d 23:59:59", time());
        }


        $stime1=date("Y-m-d", strtotime($stime));
        $this->assign('Stime',$stime1);
        $this->assign('Etime',$etime);






        // 日志点
       // $connection=db($game_id,$db_id);
        if($_GET['game_user_id']){
            $game_user_id=I('get.game_user_id');
            $ru['role_id']=$game_user_id;
            $this->assign('role_id',$game_user_id);
        }
        if($_GET['game_user_name']){
            $game_user_name=I('get.game_user_name');
            $ru['role_name']=$game_user_name;
            $this->assign('role_name',$game_user_name);
        }
        if($_GET['goods_name']){
            $goods_name=I('get.goods_name');
            $ru['prop']=$goods_name;
            $this->assign('prop',$goods_name);
        }
        if($_GET['cause']){
            $cause=I('get.cause');
            $ru['item_reason']=array('like','%'.$cause.'%');
            $this->assign('item_reason',$cause);
        }
        $ru['LogTime']=array(array('gt',$stime),array('lt',$etime));
        $count=M('backpack')->where($ru)->count();
        $Page=new \Think\Page($count,25);
        $show=$Page->show();
        $Log = M('backpack')->where($ru)->alias('a')->join('left join prop b on b.ID=a.prop')->limit($Page->firstRow.','.$Page->listRows)->select();
        foreach ($Log as $key =>$value){
            $Log[$key]['item_get']=json_decode($Log[$key]['item_get'],1);
            $Log[$key]['item_use']=json_decode($Log[$key]['item_use'],1);
            $Log[$key]['item_left']=json_decode($Log[$key]['item_left'],1);
        }

        $this->assign('page',$show);
        $this->assign("Log",$Log);
        //var money_type="{$money_type}"   类别
       /* if(isset($_GET["value"])){
            $value=I("get.value");
            if($value==1){
                $con["value"]=array('gt',0);
            }else if($value==-1){
                $con["value"]=array('lt',0);
            }
        }else{
            $value=-1;
            $con["value"]=array('lt',0);
        }
        $this->assign("value",$value);
         $Userbase = M('San_userbase','',$connection);
        if(isset($_GET["game_user_name"])){
            $game_user_name=I("get.game_user_name");
            if($game_user_name!=null){
                $where["uname"]=array('like', "%$game_user_name%");
                $uname=$Userbase->where($where)->find();

		if($uname==null){
		echo "<script>alert('用户信息错误，无法查找');location.href='http://106.15.137.174/Test/Home/Prop/index'</script>";exit;
		}
                $con["uid"]=$uname["uid"];
            }else{
                if(isset($_GET["game_user_id"])){
                    if($_GET["game_user_id"]==null){
                        $con["uid"]=null;
                    }else{
                        $con["uid"]=I("get.game_user_id");
                    }

                }else{
                    $con["uid"]=null;
                }
            }
        }else{
            if(isset($_GET["game_user_id"])){
                if($_GET["game_user_id"]=="undefined"){
                    $con["uid"]=null;
                }else{
                    $con["uid"]=I("get.game_user_id");
                }

            }else{
                $con["uid"]=null;
            }
        }


//var_dump($_GET["game_user_id"]);
        if($_GET["goods_name"]!="undefined"){
           $goods_name=I("get.goods_name");
        }else{
            $goods_name=null;
        }

        $con=array_filter($con);
	//var_dump($con);
         $count      = $San_log->where($con)->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数(20)
        $show       = $Page->show();// 分页显示输出
        $this->assign("page",$show);// 赋值分页输出
        $arr=$San_log->where($con)->limit($Page->firstRow.','.$Page->listRows)->order("id desc")->select();
//var_dump($arr);
         for($i=0;$i<count($arr);$i++){
            $goods_id=$arr[$i]["type"];
            $Gstu=D("goods")->where("itemid=$goods_id")->find();
            if($goods_name!=null){
                similar_text($goods_name, $Gstu["itemname"], $percent);

                if((float)$percent>60){
                    $arrs[$i]["goods_name"]=$Gstu["itemname"];
                    $uid=$arr[$i]["uid"];
                    $RUS=$Userbase->where("uid=$uid")->find();
                    $arrs[$i]["uname"]=$RUS["uname"];
                    $arrs[$i]["level"]=$RUS["level"];
                    $arrs[$i]["time"]=date("Y-m-d H:i:s",$arr[$i]["time"]);
                    $arrs[$i]["uid"]=$arr[$i]["uid"];
                    $arrs[$i]["dec"]=$arr[$i]["dec"];
                    $arrs[$i]["value"]=$arr[$i]["value"];
                }
            }else{
                $arrs[$i]["goods_name"]=$Gstu["itemname"];
                $uid=$arr[$i]["uid"];
                $RUS=$Userbase->where("uid=$uid")->find();
                $arrs[$i]["uname"]=$RUS["uname"];
                $arrs[$i]["level"]=$RUS["level"];
                $arrs[$i]["time"]=date("Y-m-d H:i:s",$arr[$i]["time"]);
                $arrs[$i]["uid"]=$arr[$i]["uid"];
                $arrs[$i]["dec"]=$arr[$i]["dec"];
                $arrs[$i]["value"]=$arr[$i]["value"];
            }

        }


	 $this->assign("arr",$arrs);*/



 $this->display();
}

    public function exl(){
        header("Content-Type:text/html; charset=utf-8");
        Vendor('PHPExcel.PHPExcel');
        //判断获得时间
        $clostu = D("db")->order("db_id desc")->select();
        $this->assign("clostu", $clostu);

        // 图标 默认 最新服
        if (isset($_GET["db_id"])) {
            $db_id = I("db_id");
        } else {
            $db_id = $clostu[0]["db_id"];
        }
        if ($db_id != 0) {
            $ru['server'] = $db_id;
        }


        $this->assign("db_id", $db_id);
        if (isset($_GET["start_time"]) && isset($_GET["end_time"])) {
            $stime = I("get.start_time");
            $stime=date("Y-m-d 00:00:00", strtotime($stime));
            $etime=date("Y-m-d 23:59:59", strtotime($stime));
        } else {
            $stime = date("Y-m-d 00:00:00", time());
            $etime = date("Y-m-d 23:59:59", time());
        }
        if($_GET['game_user_id']){
            $game_user_id=I('get.game_user_id');
            $ru['role_id']=$game_user_id;
        }
        if($_GET['game_user_name']){
            $game_user_name=I('get.game_user_name');
            $ru['role_name']=$game_user_name;
        }
        if($_GET['goods_name']){
            $goods_name=I('get.goods_name');
            $ru['prop']=$goods_name;
        }
        if($_GET['cause']){
            $cause=I('get.cause');
            $ru['item_reason']=$cause;
        }
        $stime1=date("Ymd", strtotime($stime));
        $ru['LogTime']=array(array('gt',$stime),array('lt',$etime));
        $Log = M('backpack')->where($ru)->select();
        foreach ($Log as $k=>$value){
            preg_match_all("/(?:\")(.*)(?:\")/i",$value['item_left'], $prop);
            $Log[$k]['prop']=$prop[1][0];
            preg_match_all("/(?:\:)(.*)(?:\})/i",$value['item_get'], $get);
            $Log[$k]['get_num']=$get[1][0];
            preg_match_all("/(?:\:)(.*)(?:\})/i",$value['item_use'], $use);
            $Log[$k]['use_num']=$use[1][0];
            preg_match_all("/(?:\:)(.*)(?:\})/i",$value['item_left'], $left);
            $Log[$k]['left_num']=$left[1][0];
            if($value['change_type']==0){
                $Log[$k]['type']="消耗";
                $Log[$k]['num']=$Log[$k]['use_num'];
            }else{
                $Log[$k]['type']="获得";
                $Log[$k]['num']=$Log[$k]['left_num'];
            }
        }



        $objPHPExcel = new \PHPExcel();

        //设置excel列名

        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', '时间');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B1', '玩家ID');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C1', '玩家名称');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D1', '玩家等级	');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E1', '原因');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F1', '物品编号');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G1', '变化类型');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H1', '剩余');

        //把数据循环写入excel中
        $i = 1;
        foreach ($Log as $key => $value) {
            $key += 2;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $key, $value["LogTime"]);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $key, $value['role_id']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $key, $value['role_name']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $key, $value['role_ChangeLife'].'重'.$value['role_level'].'级');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $key, $value['item_reason']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F' . $key, $value['prop']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G' . $key, $value['type'].'了'.$value['num'].'个');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H' . $key, $value['left_num']);

        }
        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(20);

        //导出代码
        $name='道具日志'.$stime1;
        $objPHPExcel->getActiveSheet()->setTitle('User');
        $objPHPExcel->setActiveSheetIndex(0);
        ob_end_clean();//清除缓冲区,避免乱码
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . $name . '.xls"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        $objWriter->save('php://output');
        exit;


    }
}