<?php
return array(
	'app_begin' => array('Behavior\CheckLangBehavior'),　　//表示在app_begin标签位置执行多语言检测行为。
);