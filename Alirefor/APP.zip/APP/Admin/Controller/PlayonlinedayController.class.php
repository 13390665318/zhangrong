<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/6/12 0012
 * Time: 下午 4:34
 */

namespace Admin\Controller;


class PlayeronlinedayController extends BaseController{
    public function index(){

    }


}