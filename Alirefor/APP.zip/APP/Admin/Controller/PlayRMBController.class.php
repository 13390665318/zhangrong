<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/6/12 0012
 * Time: 下午 4:36
 */

namespace Admin\Controller;


class PlayRMBController extends BaseController
{
    public function index(){
        $this->display();
    }

}