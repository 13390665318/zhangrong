<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/6/12 0012
 * Time: 上午 11:35
 */

namespace Admin\Controller;


class Invita_codeController extends BaseController
{
        public function index(){
        $this->display();
        }
}