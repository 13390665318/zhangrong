<?php
namespace Home\Controller;

class CompanyController extends BaseController {
    public function index(){

        $this->display();
    }
  
    
}