<?php
namespace Home\Controller;

class IndexController extends BaseController {
    public function index(){
        $news=M('article')->where('type=2')->select();
        $this->assign('news',$news);
        $this->display();
    }
  
    
}